package com.aws.lambda.handlers.dto;

public class Account {

	protected Long id;
	protected String accountHolderName;
	protected String mobileNo;
		
	public Account() {
		super();
	}

	public Account(Long id, String accountHolderName, String mobileNo) {
		super();
		this.id = id;
		this.accountHolderName = accountHolderName;
		this.mobileNo = mobileNo;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", accountHolderName=" + accountHolderName + ", mobileNo=" + mobileNo + "]";
	}

}
