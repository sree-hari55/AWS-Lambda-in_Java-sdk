package com.aws.lambda.handlers;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageResult;
import com.aws.lambda.handlers.dto.Account;
import com.aws.lambda.handlers.dto.SQSEventInfo;
import com.aws.lambda.handlers.service.AccountService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sns.SnsClient;
import software.amazon.awssdk.services.sns.model.PublishRequest;
import software.amazon.awssdk.services.sns.model.PublishResponse;
import software.amazon.awssdk.services.sns.model.SnsException;

/**
 * 
 * @author SRIHAGX
 * 
 * Implementing the RequestHandler interface
 *
 */
public class AccountRequestHandler implements RequestHandler<SQSEvent, String>{

	private final String SUCESS_QUEUE_URL="https://sqs.us-east-2.amazonaws.com/097206237764/AccountCreationSucesss";
	private final String DEAD_QUEUE_URL="https://sqs.us-east-2.amazonaws.com/097206237764/DeadQueue";
	private final String FAILED_TOPIC_ARN="arn:aws:sns:us-east-2:097206237764:AccountFailed";

	private AmazonSQSAsync sqs=null;
	private SnsClient snsClient=null;


	public AccountRequestHandler() {
		sqs = AmazonSQSAsyncClientBuilder.standard()
				.withRegion(Regions.US_EAST_2)
				.build();
		snsClient = SnsClient.builder()
				.region(Region.US_EAST_2)
				.build();
	}

	@Override
	public String handleRequest(SQSEvent input, Context context) {
		 LambdaLogger logger = context.getLogger();
		String response=null;

			for(SQSMessage message:input.getRecords()) {
				System.out.println("request info:{}"+message.getBody());
				logger.log("request info:{}"+message.getBody());
				ObjectMapper mapper=new ObjectMapper();
				AccountService accountService=null;
				SQSEventInfo eventInfo=null;
				try {
					eventInfo=mapper.readValue(message.getBody(), SQSEventInfo.class);
				} catch (JsonProcessingException e) {
					e.printStackTrace();
				}
				if(eventInfo.getDetail().getId()!=null && !String.valueOf(eventInfo.getDetail().getId()).isEmpty()) {
					Account account=eventInfo.getDetail();
					System.out.println("accont info:{}"+account);
					accountService=new AccountService();
					accountService.createAccount(account);	
					response=sendMessageToSucessQueue("Account creation sucess with Account no is :{}"+UUID.randomUUID());
				}else {
					throw new IllegalArgumentException();
				}
			}
		return response;
	}

	private String sendMessageToDeadQueue(String message)  {
		System.out.println("before sending message into dead queue");
		Future<SendMessageResult> smr = sqs.sendMessageAsync(new SendMessageRequest()
				.withQueueUrl(DEAD_QUEUE_URL)
				.withMessageBody(message));
		
		String messageId=processingSendMessageresult(smr);
		if(messageId!=null && !messageId.isEmpty()) {
			List<String> messageBody=consumeDeadQueueMessages();
			messageBody.stream().forEach(meaasge ->this.publishMessage(message,FAILED_TOPIC_ARN)); 
		}
		return messageId;
	}

	private String sendMessageToSucessQueue(String message)  {
		System.out.println("before sending message into success queue");
		Future<SendMessageResult> smr = sqs.sendMessageAsync(new SendMessageRequest()
				.withQueueUrl(SUCESS_QUEUE_URL)
				.withMessageBody(message));
		return processingSendMessageresult(smr);
	}

	public String processingSendMessageresult(Future<SendMessageResult> sendMessageresult) {
		String messageId=null;
		//String sequencesNumber=null;
		try {
			messageId=sendMessageresult.get().getMessageId();
			//sequencesNumber=sendMessageresult.get().getSequenceNumber();
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		return messageId;
	}

	public List<String> consumeDeadQueueMessages() {

		List<String> messageBody=null;

		List<Message> failedMessages = sqs.receiveMessage(DEAD_QUEUE_URL).getMessages();

		for (Message m : failedMessages) {
			System.out.println("cosumed falied message from queue"+m.getBody());
			messageBody=new ArrayList<String>();
			String body=m.getBody();
			messageBody.add(body);
		}
		return messageBody;
	}


	public  void publishMessage(String message,String topicArn) {
		try {
			PublishRequest request = PublishRequest.builder()
					.message(message)
					.topicArn(topicArn)
					.build();

			PublishResponse result = snsClient.publish(request);
			System.out.println(result.messageId() + " Message sent. Status was " + result.sdkHttpResponse().statusCode());

		} catch (SnsException e) {
			System.err.println(e.awsErrorDetails().errorMessage());
			System.exit(1);
		}finally {
			snsClient.close();
		}
	}
}