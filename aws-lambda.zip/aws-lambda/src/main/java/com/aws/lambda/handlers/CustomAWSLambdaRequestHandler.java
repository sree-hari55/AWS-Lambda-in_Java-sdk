package com.aws.lambda.handlers;

import com.amazonaws.services.lambda.runtime.Context;

// Custom Request Handler

public class CustomAWSLambdaRequestHandler {

	public Object customHandler(String input) {
		System.out.println("Custom Lambda has been invoked{}"+input);
		return input;
	}
	
	
	// All AWS environment info is available in Context object like memory,time
	public Object customHandlerWithContext(String input,Context context) {
		if(input!=null && !input.isEmpty()) {
			System.out.println("context info {}"+context.getMemoryLimitInMB());
			return input;
		}return context;
	}
	

	public Object customHandlerWithoutInput() {
		return "AWS lambda function has invoked through API Gateway.";
	} 
}
