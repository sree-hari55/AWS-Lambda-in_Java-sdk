package com.aws.lambda.handlers.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.aws.lambda.handlers.dto.Account;


public class AccountService {

	private List<Account> accounts=new ArrayList<Account>(Arrays.asList( new
			Account(101L, "John", "8897678561"), new Account(102L, "Rock",
					"8897678561"), new Account(103L, "Sachin", "8897678561"), new Account(104L,
							"Rohit", "8897678561"), new Account(105L, "Tom", "8897678561")));


	public void createAccount(Account account) {
		accounts.add(account);
	}

	public List<Account> getAccounts(){
		return accounts;
	}

}
