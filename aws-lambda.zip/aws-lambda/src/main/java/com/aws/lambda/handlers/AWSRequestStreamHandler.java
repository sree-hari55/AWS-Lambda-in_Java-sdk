package com.aws.lambda.handlers;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
// We can write function using RequestStreamHandler
public class AWSRequestStreamHandler implements RequestStreamHandler{

	public void handleRequest(InputStream input, OutputStream output, Context context) throws IOException {
		byte[] b=input.readAllBytes();
		String s=String.valueOf(b);
		System.out.println("Input stream Data{}"+s);
		output.write(b);
	}
}
