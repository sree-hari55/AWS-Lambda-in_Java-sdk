package com.aws.lambda.handlers.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SQSEventInfo {

	public String version;
	public String id;
	@JsonProperty("detail-type") 
	public String detailType;
	public String source;
	public String account;
	public Date time;
	public String region;
	public List<Object> resources;
	public Account detail;


	public SQSEventInfo() {
		super();
	}


	public SQSEventInfo(String version, String id, String detailType, String source, String account, Date time,
			String region, List<Object> resources, Account detail) {
		super();
		this.version = version;
		this.id = id;
		this.detailType = detailType;
		this.source = source;
		this.account = account;
		this.time = time;
		this.region = region;
		this.resources = resources;
		this.detail = detail;
	}


	public String getVersion() {
		return version;
	}


	public void setVersion(String version) {
		this.version = version;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getDetailType() {
		return detailType;
	}


	public void setDetailType(String detailType) {
		this.detailType = detailType;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getAccount() {
		return account;
	}


	public void setAccount(String account) {
		this.account = account;
	}


	public Date getTime() {
		return time;
	}


	public void setTime(Date time) {
		this.time = time;
	}


	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}


	public List<Object> getResources() {
		return resources;
	}


	public void setResources(List<Object> resources) {
		this.resources = resources;
	}


	public Account getDetail() {
		return detail;
	}


	public void setDetail(Account detail) {
		this.detail = detail;
	}


	@Override
	public String toString() {
		return "SQSEventInfo [version=" + version + ", id=" + id + ", detailType=" + detailType + ", source=" + source
				+ ", account=" + account + ", time=" + time + ", region=" + region + ", resources=" + resources
				+ ", detail=" + detail + "]";
	}


}