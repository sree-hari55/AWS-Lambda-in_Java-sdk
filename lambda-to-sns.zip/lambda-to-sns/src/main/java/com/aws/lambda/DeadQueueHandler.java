package com.aws.lambda;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sns.SnsAsyncClient;
import software.amazon.awssdk.services.sns.model.PublishRequest;
import software.amazon.awssdk.services.sns.model.PublishResponse;
import software.amazon.awssdk.services.sns.model.SnsException;

/**
 * - srihari.g
 *
 */
public class DeadQueueHandler implements RequestHandler<SQSEvent,Object> {
	private final String FAILED_TOPIC_ARN="arn:aws:sns:us-east-2:097206237764:AccountFailed";
	private SnsAsyncClient snsAsyncClient=null;
	

	public DeadQueueHandler() {
		this.snsAsyncClient=SnsAsyncClient
				 .builder()
				 .region(Region.US_EAST_2)
				 .build();
	}
	public List<String> handleRequest(SQSEvent input, Context context) {
		return input.getRecords().stream().map(message ->{
			this.publishMessage(message.getBody(),FAILED_TOPIC_ARN);
			return "message sending sucessfully";
		}).collect(Collectors.toList());
	}
	
	public  void publishMessage(String message,String topicArn)  {
		try {
			PublishRequest request = PublishRequest.builder()
					.message(message)
					.topicArn(topicArn)
					.build();

			CompletableFuture<PublishResponse> result = snsAsyncClient.publish(request);
			try {
				System.out.println(result.get().messageId() + " Message sent. Status was " + result.get().sdkHttpResponse().statusCode());
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}

		} catch (SnsException e) {
			System.err.println(e.awsErrorDetails().errorMessage());
			System.exit(1);
		}finally {
			snsAsyncClient.close();
		}

	}

}
